package usersTests;

import static io.restassured.RestAssured.get;

import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import usersDetails.UserDetail;
import utilities.parseUserDetails;

public class GetUserTests {
	
	@BeforeClass
	public void setup() {
		RestAssured.baseURI = "https://jsonplaceholder.typicode.com/users";
	}

	@Test
	public void verifyResponseForValidExistingUser()
	{
		get("/1").
			then().assertThat()
			.statusCode(200)
			.statusCode(HttpStatus.SC_OK)
			.contentType("application/json");
	}
	
	@Test
	public void verifyResponseForInValidUser()
	{
		get("/100").
			then().assertThat()
			.statusCode(404)
			.statusCode(HttpStatus.SC_NOT_FOUND)
			.contentType("application/json");
	}
	
	@Test
	public void verifyResponseDetailsForValidExistingUser()
	{
		Response response = get("/1");
		String jsonResponseBody = response.body().asString();
		UserDetail userdetail = parseUserDetails.parseUserDetailStringToObject(jsonResponseBody);
		
		Assert.assertEquals(userdetail.getName(), "Leanne Graham", 
				"Retrieved User name not matched with expected");
		Assert.assertEquals(userdetail.getEmail(), "Sincere@april.biz", 
				"Retrieved Email not matched with expected");
		Assert.assertEquals(userdetail.getAddress().getStreet(), "Kulas Light", 
				"Retrieved Address - Street not matched with expected");
		Assert.assertEquals(userdetail.getAddress().getSuite(), "Apt. 556", 
				"Retrieved Address - Suite not matched with expected");
		Assert.assertEquals(userdetail.getAddress().getCity(), "Gwenborough", 
				"Retrieved Address - City not matched with expected");
		Assert.assertEquals(userdetail.getAddress().getZipcode(), "92998-3874", 
				"Retrieved Address - Zipcode not matched with expected");
		Assert.assertEquals(userdetail.getAddress().getGeo().getLat(), "-37.3159", 
				"Retrieved Address - Geo latitude not matched with expected");
		Assert.assertEquals(userdetail.getAddress().getGeo().getLng(), "81.1496", 
				"Retrieved Address - Geo longitude not matched with expected");
		Assert.assertEquals(userdetail.getPhone(), "1-770-736-8031 x56442", 
				"Retrieved Phone not matched with expected");
		Assert.assertEquals(userdetail.getWebsite(), "hildegard.org", 
				"Retrieved Website not matched with expected");
	}
	
	@AfterClass
	public void teardown() {
		RestAssured.reset();
	}
}
