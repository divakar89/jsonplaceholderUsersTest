package usersTests;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import usersDetails.Address;
import usersDetails.Company;
import usersDetails.GeoLocation;
import usersDetails.UserDetail;
import utilities.parseUserDetails;

public class UpdateUserTests {

	@BeforeClass
	public void setup() {
		RestAssured.baseURI = "https://jsonplaceholder.typicode.com/users";
	}
	
	@Test
	public void verifyResponseDetailsWhileEditingExistingUser()
	{
		//setting test data for editing existing user - building pojo
		GeoLocation geo = new GeoLocation();
		geo.setLat("");
		geo.setLng("");
		
		Address address = new Address();
		address.setGeoLocation(geo);
		address.setCity("Test City");
		address.setStreet("Test street");
		address.setSuite("Test Suite");
		address.setZipcode("Test zipcode");
		
		Company company = new Company();
		company.setName("Test company");
		company.setCatchPhrase("Test catchphrase");
		company.setBs("Test bs");
		
		UserDetail userdetail = new UserDetail();
		userdetail.setAddress(address);
		userdetail.setCompany(company);
		userdetail.setEmail("test@ibiz.com");
		userdetail.setId(1);
		userdetail.setName("Divakar Arumugam");
		userdetail.setPhone("+44 7474747474");
		userdetail.setUsername("divakar89");
		userdetail.setWebsite("testbiz.com");
		
		String jsonRequestBody = parseUserDetails.parseUserDetailObjectToString(userdetail);
		Response response = given()
                .header("Content-type", "application/json")
                .and()
                .body(jsonRequestBody)
                .when()
                .put("/1")
                .then()
                .extract().response();
		
		Assert.assertEquals(200, response.statusCode());
		Assert.assertEquals("Divakar Arumugam", response.jsonPath().getString("name"));
		Assert.assertEquals("divakar89", response.jsonPath().getString("username"));
		Assert.assertEquals("test@ibiz.com", response.jsonPath().getString("email"));
		Assert.assertEquals("1", response.jsonPath().getString("id"));
	}
	
	@AfterClass
	public void teardown() {
		RestAssured.reset();
	}
}
