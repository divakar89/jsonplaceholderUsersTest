package usersTests;

import static io.restassured.RestAssured.*;

import java.util.ArrayList;

import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class GetAllUserTests {
	
	@BeforeClass
	public void setup() {
		RestAssured.baseURI = "https://jsonplaceholder.typicode.com/users";
	}

	@Test
	public void verifyTotalUsersCountGreaterThanZero()
	{
		ArrayList<String> userIDs = get().
			then().assertThat()
			.statusCode(200)
			.statusCode(HttpStatus.SC_OK)
			.contentType("application/json")
			.extract().path("id");
			
		Assert.assertTrue(userIDs.size() > 0, "No users returned, Users count zero");
	}
	
	@AfterClass
	public void teardown() {
		RestAssured.reset();
	}

}
