package utilities;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import usersDetails.UserDetail;

public class parseUserDetails {

	public static UserDetail parseUserDetailStringToObject (String userdetailJsonData) {
		
		// ObjectMapper instantiation
		ObjectMapper objectMapper = new ObjectMapper();
		
		// Parsing into the `UserDetail` pojo class
		UserDetail userdetail = null;
		try {
			userdetail = objectMapper.readValue(userdetailJsonData, UserDetail.class);
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userdetail;
	}
	
	public static String parseUserDetailObjectToString (UserDetail userdetail) {
		
		// ObjectMapper instantiation
		ObjectMapper objectMapper = new ObjectMapper();
		
		try {
			return objectMapper.writeValueAsString(userdetail);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
