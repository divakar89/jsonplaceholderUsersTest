Project Name: jsonplaceholderUsersTest
Language: java

Dependencies:
1. Rest-assured library
2. TestNG for test execution
3. Maven- for build and execution

Steps to execute USERS tests
1) Reach out to maven pom xml file
2) Update maven dependencies. (all included in pom xml) 
3) Run maven pom xml as Maven Test (test classes already configured in testng.xml file)